import { useState, useRef, useEffect } from "react";

const LOKASI_DATA = {
  "Jakarta": { koef: 1.00, provinsi: "DKI Jakarta", catatan: "Basis referensi nasional" },
  "Bogor": { koef: 0.93, provinsi: "Jawa Barat", catatan: "" },
  "Bandung": { koef: 0.92, provinsi: "Jawa Barat", catatan: "" },
  "Bekasi": { koef: 0.95, provinsi: "Jawa Barat", catatan: "" },
  "Semarang": { koef: 0.89, provinsi: "Jawa Tengah", catatan: "" },
  "Yogyakarta": { koef: 0.87, provinsi: "DI Yogyakarta", catatan: "" },
  "Surabaya": { koef: 0.91, provinsi: "Jawa Timur", catatan: "" },
  "Malang": { koef: 0.88, provinsi: "Jawa Timur", catatan: "" },
  "Denpasar": { koef: 0.95, provinsi: "Bali", catatan: "Kota utama Bali" },
  "Badung": { koef: 0.94, provinsi: "Bali", catatan: "Kuta, Seminyak, Nusa Dua" },
  "Buleleng": { koef: 0.88, provinsi: "Bali", catatan: "Singaraja — Bali Utara" },
  "Gianyar": { koef: 0.90, provinsi: "Bali", catatan: "Ubud, Gianyar" },
  "Karangasem": { koef: 0.85, provinsi: "Bali", catatan: "Amlapura — Bali Timur" },
  "Tabanan": { koef: 0.87, provinsi: "Bali", catatan: "" },
  "Klungkung": { koef: 0.86, provinsi: "Bali", catatan: "" },
  "Jembrana": { koef: 0.85, provinsi: "Bali", catatan: "Bali Barat" },
  "Bangli": { koef: 0.84, provinsi: "Bali", catatan: "" },
  "Mataram": { koef: 0.89, provinsi: "NTB", catatan: "" },
  "Kupang": { koef: 0.92, provinsi: "NTT", catatan: "Biaya logistik tinggi" },
  "Medan": { koef: 0.94, provinsi: "Sumatera Utara", catatan: "" },
  "Palembang": { koef: 0.90, provinsi: "Sumatera Selatan", catatan: "" },
  "Pekanbaru": { koef: 0.93, provinsi: "Riau", catatan: "" },
  "Batam": { koef: 0.98, provinsi: "Kepulauan Riau", catatan: "Material impor dominan" },
  "Padang": { koef: 0.89, provinsi: "Sumatera Barat", catatan: "" },
  "Banda Aceh": { koef: 0.92, provinsi: "Aceh", catatan: "" },
  "Balikpapan": { koef: 1.05, provinsi: "Kalimantan Timur", catatan: "IKK tinggi" },
  "Samarinda": { koef: 1.03, provinsi: "Kalimantan Timur", catatan: "" },
  "Banjarmasin": { koef: 0.95, provinsi: "Kalimantan Selatan", catatan: "" },
  "Pontianak": { koef: 0.96, provinsi: "Kalimantan Barat", catatan: "" },
  "Makassar": { koef: 0.93, provinsi: "Sulawesi Selatan", catatan: "" },
  "Manado": { koef: 0.97, provinsi: "Sulawesi Utara", catatan: "" },
  "Ambon": { koef: 1.08, provinsi: "Maluku", catatan: "Logistik tinggi" },
  "Jayapura": { koef: 1.25, provinsi: "Papua", catatan: "IKK tertinggi nasional" },
  "Sorong": { koef: 1.18, provinsi: "Papua Barat", catatan: "" },
};

const AHSP_DEFAULT = [
  { kode: "A.1", uraian: "Pek. Persiapan & Pembongkaran", satuan: "m²", harga: 85000 },
  { kode: "B.1", uraian: "Pek. Pondasi Bored Pile", satuan: "m¹", harga: 1250000 },
  { kode: "C.1", uraian: "Pek. Beton Kolom 40x40", satuan: "m³", harga: 5200000 },
  { kode: "C.3", uraian: "Pek. Pelat Lantai Beton", satuan: "m²", harga: 750000 },
  { kode: "D.1", uraian: "Pek. Dinding Bata Ringan", satuan: "m²", harga: 185000 },
  { kode: "D.2", uraian: "Pek. Plesteran & Acian", satuan: "m²", harga: 95000 },
  { kode: "E.1", uraian: "Pek. Keramik Lantai 60x60", satuan: "m²", harga: 220000 },
  { kode: "E.2", uraian: "Pek. Epoxy Lantai (OK/ICU)", satuan: "m²", harga: 450000 },
  { kode: "E.3", uraian: "Pek. Vinyl Medis", satuan: "m²", harga: 380000 },
  { kode: "F.1", uraian: "Pek. Plafond Gypsum", satuan: "m²", harga: 175000 },
  { kode: "F.2", uraian: "Pek. Plafond GRC/Cleanroom", satuan: "m²", harga: 350000 },
  { kode: "G.1", uraian: "Pek. Kusen + Pintu Aluminium", satuan: "unit", harga: 3500000 },
  { kode: "G.2", uraian: "Pek. Pintu Hermetic (OK)", satuan: "unit", harga: 45000000 },
  { kode: "H.1", uraian: "Instalasi Listrik per Titik", satuan: "titik", harga: 450000 },
  { kode: "H.2", uraian: "Pek. Panel Listrik", satuan: "unit", harga: 18000000 },
  { kode: "H.3", uraian: "Pek. Genset (per kVA)", satuan: "kVA", harga: 2500000 },
  { kode: "I.1", uraian: "Instalasi Air Bersih per Titik", satuan: "titik", harga: 850000 },
  { kode: "I.2", uraian: "Instalasi Air Kotor per Titik", satuan: "titik", harga: 950000 },
  { kode: "J.1", uraian: "Instalasi Gas Medis O2", satuan: "outlet", harga: 3500000 },
  { kode: "J.2", uraian: "Instalasi Gas Vakum", satuan: "outlet", harga: 3200000 },
  { kode: "K.1", uraian: "Pek. AC Split (per PK)", satuan: "PK", harga: 4500000 },
  { kode: "K.2", uraian: "Pek. HVAC Cleanroom", satuan: "m²", harga: 1800000 },
  { kode: "L.1", uraian: "Pek. Pengecatan Dinding", satuan: "m²", harga: 55000 },
  { kode: "L.2", uraian: "Pek. Cat Epoxy Dinding Medis", satuan: "m²", harga: 185000 },
  { kode: "M.1", uraian: "Pek. Partisi Gypsum Dobel+Rangka", satuan: "m²", harga: 270000 },
  { kode: "M.2", uraian: "Pek. Rockwool 50mm", satuan: "m²", harga: 85000 },
  { kode: "M.3", uraian: "Pek. Glasswool 50mm", satuan: "m²", harga: 55000 },
  { kode: "N.1", uraian: "Pek. Granite Tile 60x60 Cream", satuan: "m²", harga: 220000 },
  { kode: "N.2", uraian: "Pek. Lis Skirting Cove Tile", satuan: "m¹", harga: 185000 },
  { kode: "O.1", uraian: "Sanitair Kloset Duduk+Wastafel", satuan: "set", harga: 3500000 },
  { kode: "O.2", uraian: "Wastafel + Instalasi", satuan: "unit", harga: 1700000 },
  { kode: "P.1", uraian: "Lampu LED Cool White 6000K", satuan: "unit", harga: 350000 },
];

const buildSystemPrompt = (lokasi, koef, ahspData, tahun) => {
  const lokasiInfo = LOKASI_DATA[lokasi] || {};
  const ahspLines = ahspData.map(a => {
    const hargaLok = Math.round(a.harga * koef / 1000) * 1000;
    return `${a.kode} | ${a.uraian} | ${a.satuan} | Rp ${hargaLok.toLocaleString("id-ID")}`;
  }).join("\n");
  return `Kamu adalah AI Agent Engineering khusus untuk Rumah Sakit (RS), dirancang untuk membantu Komisaris Utama RS dalam perencanaan, review, dan negosiasi proyek konstruksi/renovasi RS.

LOKASI PROYEK AKTIF: ${lokasi} (${lokasiInfo.provinsi || ""}) | KOEFISIEN: x${koef}
SEMUA harga estimasi WAJIB menggunakan harga lokasi ${lokasi} (sudah dikali x${koef}).

KEAHLIAN: Arsitektur RS, Struktur, MEP (Listrik/Plumbing/Gas Medis/HVAC), Estimasi Biaya AHSP, Review Permenkes 24/2016 & SNARS.

CARA KERJA: Upload gambar→analisis. Estimasi biaya→gunakan AHSP lokasi. Review proposal→counter-analisis. Output selalu actionable untuk negosiasi.

FORMAT: Bahasa Indonesia profesional. Poin kunci untuk keputusan. Sertakan flag standar dan range estimasi.

[DATA AHSP — ${lokasi} — Tahun ${tahun}]
${ahspLines}`;
};

// API Key Screen
function ApiKeyScreen({ onSave }) {
  const [key, setKey] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState("");
  const [testing, setTesting] = useState(false);

  const handleSave = async () => {
    if (!key.startsWith("sk-ant-")) {
      setError("API Key tidak valid. Harus dimulai dengan 'sk-ant-'");
      return;
    }
    setTesting(true);
    setError("");
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
        body: JSON.stringify({ model: "claude-haiku-4-5-20251001", max_tokens: 10, messages: [{ role: "user", content: "hi" }] }),
      });
      if (res.ok) { onSave(key); }
      else { setError("API Key ditolak. Pastikan key aktif dan benar."); }
    } catch {
      setError("Gagal terhubung. Cek koneksi internet Anda.");
    }
    setTesting(false);
  };

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(135deg,#0d2b4e,#1a4a7a)", display: "flex", alignItems: "center", justifyContent: "center", padding: 20, fontFamily: "Georgia, serif" }}>
      <div style={{ background: "white", borderRadius: 16, padding: 36, maxWidth: 480, width: "100%", boxShadow: "0 20px 60px rgba(0,0,0,0.3)" }}>
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <div style={{ fontSize: 48, marginBottom: 10 }}>🏥</div>
          <div style={{ fontWeight: 700, fontSize: 20, color: "#0d2b4e" }}>RS Engineering Agent</div>
          <div style={{ fontSize: 13, color: "#666", marginTop: 4 }}>Asisten Teknik Komisaris Utama</div>
        </div>

        <div style={{ background: "#f0f7ff", borderRadius: 10, padding: 16, marginBottom: 22, borderLeft: "4px solid #1565a0" }}>
          <div style={{ fontWeight: 700, fontSize: 13, color: "#1a3a5c", marginBottom: 6 }}>🔑 Diperlukan: Anthropic API Key</div>
          <div style={{ fontSize: 12.5, color: "#444", lineHeight: 1.6 }}>
            Untuk mengaktifkan AI Agent, Anda perlu API Key dari Anthropic.
            Key ini <strong>hanya tersimpan di browser Anda</strong> dan tidak dikirim ke server manapun selain Anthropic.
          </div>
        </div>

        <div style={{ marginBottom: 16 }}>
          <label style={{ fontSize: 12.5, fontWeight: 600, color: "#1a3a5c", display: "block", marginBottom: 6 }}>Masukkan API Key Anda:</label>
          <div style={{ position: "relative" }}>
            <input
              type={show ? "text" : "password"}
              value={key}
              onChange={e => { setKey(e.target.value); setError(""); }}
              placeholder="sk-ant-api03-..."
              style={{ width: "100%", padding: "10px 44px 10px 12px", border: "1.5px solid #c5d5e8", borderRadius: 8, fontSize: 13, outline: "none", fontFamily: "monospace", boxSizing: "border-box" }}
            />
            <button onClick={() => setShow(!show)} style={{ position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", fontSize: 16, opacity: 0.6 }}>
              {show ? "🙈" : "👁️"}
            </button>
          </div>
          {error && <div style={{ fontSize: 12, color: "#e53935", marginTop: 6 }}>⚠️ {error}</div>}
        </div>

        <button
          onClick={handleSave}
          disabled={!key || testing}
          style={{ width: "100%", background: !key || testing ? "#9ab" : "linear-gradient(135deg,#1565a0,#0d2b4e)", color: "white", border: "none", padding: "12px", borderRadius: 9, fontSize: 14, fontWeight: 700, cursor: !key || testing ? "not-allowed" : "pointer", fontFamily: "inherit" }}
        >
          {testing ? "Memverifikasi..." : "Aktifkan Agent →"}
        </button>

        <div style={{ marginTop: 20, padding: 14, background: "#fffde7", borderRadius: 8, fontSize: 12, color: "#795548", lineHeight: 1.7 }}>
          <strong>Cara mendapatkan API Key:</strong><br />
          1. Buka <strong>console.anthropic.com</strong><br />
          2. Login / Daftar akun<br />
          3. Klik <strong>"API Keys"</strong> di menu kiri<br />
          4. Klik <strong>"Create Key"</strong> → Copy key<br />
          5. Paste di kolom di atas
        </div>
      </div>
    </div>
  );
}

export default function RSEngineeringAgent() {
  const tahun = new Date().getFullYear();
  const [apiKey, setApiKey] = useState(() => localStorage.getItem("rs_agent_apikey") || "");
  const [lokasi, setLokasi] = useState("Buleleng");
  const [lokasiSearch, setLokasiSearch] = useState("");
  const [showLokasiDropdown, setShowLokasiDropdown] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [pendingImages, setPendingImages] = useState([]);
  const [activeTab, setActiveTab] = useState("chat");
  const [ahspData, setAhspData] = useState(AHSP_DEFAULT);
  const [ahspSearch, setAhspSearch] = useState("");
  const [newAhsp, setNewAhsp] = useState({ kode: "", uraian: "", satuan: "", harga: "" });
  const fileInputRef = useRef(null);
  const chatEndRef = useRef(null);
  const lokasiRef = useRef(null);

  const lokasiInfo = LOKASI_DATA[lokasi] || { koef: 1.0, provinsi: "", catatan: "" };
  const koef = lokasiInfo.koef;
  const hargaLokasi = (base) => Math.round(base * koef / 1000) * 1000;
  const fmt = (n) => "Rp " + n.toLocaleString("id-ID");

  const handleSaveKey = (key) => {
    localStorage.setItem("rs_agent_apikey", key);
    setApiKey(key);
  };

  useEffect(() => {
    if (!apiKey) return;
    setMessages([{
      role: "assistant",
      content: `Selamat datang, Pak Komisaris.\n\nSaya **RS Engineering Agent** siap membantu analisis gambar teknik, estimasi biaya, dan review proyek RS.\n\n📍 **Lokasi aktif: ${lokasi}** — ${lokasiInfo.provinsi}\n💰 **Koefisien harga: x${koef}** dari baseline Jakarta\n\nAda yang bisa saya bantu?`,
      images: [],
    }]);
  }, [apiKey]);

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, isLoading]);
  useEffect(() => {
    const h = (e) => { if (lokasiRef.current && !lokasiRef.current.contains(e.target)) setShowLokasiDropdown(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  if (!apiKey) return <ApiKeyScreen onSave={handleSaveKey} />;

  const filteredLokasi = Object.entries(LOKASI_DATA).filter(([k, v]) =>
    k.toLowerCase().includes(lokasiSearch.toLowerCase()) || v.provinsi.toLowerCase().includes(lokasiSearch.toLowerCase())
  );

  const handleImageUpload = (e) => {
    Array.from(e.target.files).forEach(file => {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const base64 = ev.target.result.split(",")[1];
        setPendingImages(p => [...p, { base64, mediaType: file.type, name: file.name }]);
      };
      reader.readAsDataURL(file);
    });
    e.target.value = "";
  };

  const buildApiMessages = (history, userText, images) => {
    const apiMsgs = [];
    for (const msg of history) {
      if (msg.role === "user") {
        const c = [];
        msg.images?.forEach(img => c.push({ type: "image", source: { type: "base64", media_type: img.mediaType, data: img.base64 } }));
        c.push({ type: "text", text: msg.content });
        apiMsgs.push({ role: "user", content: c });
      } else { apiMsgs.push({ role: "assistant", content: msg.content }); }
    }
    const uc = [];
    images.forEach(img => uc.push({ type: "image", source: { type: "base64", media_type: img.mediaType, data: img.base64 } }));
    uc.push({ type: "text", text: userText });
    apiMsgs.push({ role: "user", content: uc });
    return apiMsgs;
  };

  const sendMessage = async () => {
    if (!input.trim() && !pendingImages.length) return;
    const userMsg = { role: "user", content: input || "(upload gambar)", images: pendingImages };
    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setInput("");
    const imgs = [...pendingImages];
    setPendingImages([]);
    setIsLoading(true);
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
        body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 1500, system: buildSystemPrompt(lokasi, koef, ahspData, tahun), messages: buildApiMessages(messages, input || "Tolong analisis gambar ini.", imgs) }),
      });
      const data = await res.json();
      const text = data.content?.map(c => c.text || "").join("") || "Maaf, tidak ada respons.";
      setMessages([...newHistory, { role: "assistant", content: text, images: [] }]);
    } catch {
      setMessages([...newHistory, { role: "assistant", content: "⚠️ Terjadi kesalahan. Periksa koneksi internet atau API Key Anda.", images: [] }]);
    }
    setIsLoading(false);
  };

  const handleKeyDown = (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } };

  const formatMsg = (text) => text.split("\n").map((line, i) => {
    line = line.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/\*(.+?)\*/g, "<em>$1</em>");
    if (line.startsWith("• ") || line.startsWith("- ")) return <li key={i} dangerouslySetInnerHTML={{ __html: line.slice(2) }} style={{ marginLeft: 16, marginBottom: 2 }} />;
    if (line.startsWith("## ")) return <p key={i} style={{ fontWeight: 700, fontSize: 11.5, color: "#1a3a5c", margin: "10px 0 3px", textTransform: "uppercase" }} dangerouslySetInnerHTML={{ __html: line.slice(3) }} />;
    if (line === "") return <div key={i} style={{ height: 5 }} />;
    return <p key={i} style={{ margin: "2px 0", lineHeight: 1.6 }} dangerouslySetInnerHTML={{ __html: line }} />;
  });

  const filteredAhsp = ahspData.filter(a => a.uraian.toLowerCase().includes(ahspSearch.toLowerCase()) || a.kode.toLowerCase().includes(ahspSearch.toLowerCase()));
  const koefBadge = (k) => ({ background: k < 0.90 ? "#e8f5e9" : k > 1.0 ? "#ffebee" : "#e3f2fd", color: k < 0.90 ? "#2e7d32" : k > 1.0 ? "#c62828" : "#1565a0", padding: "2px 7px", borderRadius: 4, fontWeight: 700, fontSize: 12 });

  return (
    <div style={{ fontFamily: "Georgia, serif", background: "#eef2f7", minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      {/* HEADER */}
      <div style={{ background: "linear-gradient(135deg,#0d2b4e,#1a4a7a,#1565a0)", color: "white", padding: "11px 16px", display: "flex", alignItems: "center", justifyContent: "space-between", boxShadow: "0 2px 12px rgba(0,0,0,0.3)", flexWrap: "wrap", gap: 8 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 34, height: 34, background: "rgba(255,255,255,0.15)", borderRadius: 7, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 17 }}>🏥</div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 13.5 }}>RS Engineering Agent</div>
            <div style={{ fontSize: 10.5, opacity: 0.7, fontStyle: "italic" }}>Asisten Teknik Komisaris Utama</div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <div ref={lokasiRef} style={{ position: "relative" }}>
            <button onClick={() => setShowLokasiDropdown(!showLokasiDropdown)} style={{ background: "rgba(255,255,255,0.12)", border: "1px solid rgba(255,255,255,0.25)", color: "white", padding: "6px 11px", borderRadius: 8, cursor: "pointer", fontSize: 12, fontFamily: "inherit", display: "flex", alignItems: "center", gap: 7 }}>
              <span>📍</span>
              <div style={{ textAlign: "left" }}><div style={{ fontWeight: 700 }}>{lokasi}</div><div style={{ fontSize: 10, opacity: 0.8 }}>{lokasiInfo.provinsi}</div></div>
              <span style={{ background: "rgba(255,255,255,0.2)", ...koefBadge(koef), color: "white" }}>x{koef}</span>
              <span style={{ opacity: 0.7 }}>▾</span>
            </button>
            {showLokasiDropdown && (
              <div style={{ position: "absolute", right: 0, top: "calc(100% + 4px)", background: "white", borderRadius: 10, boxShadow: "0 8px 32px rgba(0,0,0,0.25)", width: 300, zIndex: 200, overflow: "hidden" }}>
                <div style={{ padding: "9px 11px", borderBottom: "1px solid #eef2f7" }}>
                  <input autoFocus value={lokasiSearch} onChange={e => setLokasiSearch(e.target.value)} placeholder="Cari kota / provinsi..." style={{ width: "100%", padding: "6px 10px", border: "1px solid #c5d5e8", borderRadius: 6, fontSize: 12, outline: "none", boxSizing: "border-box" }} />
                </div>
                <div style={{ maxHeight: 280, overflowY: "auto" }}>
                  {filteredLokasi.map(([kota, info]) => (
                    <div key={kota} onClick={() => { setLokasi(kota); setShowLokasiDropdown(false); setLokasiSearch(""); }} style={{ padding: "8px 13px", cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center", background: lokasi === kota ? "#e8f0fe" : "white", borderBottom: "1px solid #f5f7fa" }}>
                      <div><div style={{ fontSize: 13, fontWeight: 600, color: "#1a3a5c" }}>{kota}</div><div style={{ fontSize: 11, color: "#888" }}>{info.provinsi}{info.catatan ? ` — ${info.catatan}` : ""}</div></div>
                      <span style={koefBadge(info.koef)}>x{info.koef}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          <button onClick={() => { localStorage.removeItem("rs_agent_apikey"); setApiKey(""); }} style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.2)", color: "rgba(255,255,255,0.7)", fontSize: 11, padding: "5px 9px", borderRadius: 6, cursor: "pointer", fontFamily: "inherit" }} title="Ganti API Key">🔑</button>
        </div>
      </div>

      {/* INFO BAR */}
      <div style={{ background: koef > 1.0 ? "#fff3e0" : "#e3f2fd", padding: "5px 16px", fontSize: 11.5, color: koef > 1.0 ? "#e65100" : "#1565a0", borderBottom: "1px solid rgba(0,0,0,0.07)" }}>
        📌 Estimasi menggunakan koefisien <strong>x{koef}</strong> untuk <strong>{lokasi}</strong>, {lokasiInfo.provinsi}.{lokasiInfo.catatan ? ` ${lokasiInfo.catatan}.` : ""}
      </div>

      {/* TABS */}
      <div style={{ background: "#1a3a5c", display: "flex", padding: "0 16px" }}>
        {[["chat","💬 Chat Agent"],["ahsp","📊 AHSP"],["koefisien","🗺️ Koefisien"]].map(([tab, label]) => (
          <button key={tab} onClick={() => setActiveTab(tab)} style={{ background: "none", border: "none", color: activeTab===tab?"#7ec8f5":"rgba(255,255,255,0.5)", fontFamily: "inherit", fontSize: 12, padding: "9px 14px", cursor: "pointer", borderBottom: activeTab===tab?"2px solid #7ec8f5":"2px solid transparent", fontWeight: activeTab===tab?700:400, textTransform: "uppercase", letterSpacing: "0.07em" }}>{label}</button>
        ))}
      </div>

      {/* CHAT */}
      {activeTab === "chat" && (
        <div style={{ flex: 1, display: "flex", flexDirection: "column", maxWidth: 860, width: "100%", margin: "0 auto", padding: "12px 12px 0", boxSizing: "border-box" }}>
          <div style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 9, paddingBottom: 9, maxHeight: "calc(100vh - 310px)" }}>
            {messages.map((msg, i) => (
              <div key={i} style={{ display: "flex", justifyContent: msg.role==="user"?"flex-end":"flex-start", alignItems: "flex-start", gap: 7 }}>
                {msg.role==="assistant" && <div style={{ width: 29, height: 29, borderRadius: 7, background: "#1a4a7a", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15, flexShrink: 0, marginTop: 2 }}>🏥</div>}
                <div style={{ maxWidth: "78%", background: msg.role==="user"?"linear-gradient(135deg,#1565a0,#0d2b4e)":"white", color: msg.role==="user"?"white":"#1a1a2e", padding: "9px 13px", borderRadius: msg.role==="user"?"14px 4px 14px 14px":"4px 14px 14px 14px", boxShadow: "0 2px 8px rgba(0,0,0,0.09)", fontSize: 13 }}>
                  {msg.images?.length > 0 && <div style={{ display: "flex", flexWrap: "wrap", gap: 5, marginBottom: 6 }}>{msg.images.map((img, j) => <img key={j} src={`data:${img.mediaType};base64,${img.base64}`} alt="" style={{ maxWidth: 160, maxHeight: 110, borderRadius: 5, objectFit: "contain" }} />)}</div>}
                  {msg.role==="assistant" ? <div>{formatMsg(msg.content)}</div> : <span>{msg.content}</span>}
                </div>
                {msg.role==="user" && <div style={{ width: 29, height: 29, borderRadius: 7, background: "#dce8fa", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, flexShrink: 0, marginTop: 2 }}>👤</div>}
              </div>
            ))}
            {isLoading && (
              <div style={{ display: "flex", gap: 7 }}>
                <div style={{ width: 29, height: 29, borderRadius: 7, background: "#1a4a7a", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15 }}>🏥</div>
                <div style={{ background: "white", padding: "10px 13px", borderRadius: "4px 14px 14px 14px", boxShadow: "0 2px 8px rgba(0,0,0,0.09)" }}>
                  <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
                    {[0,1,2].map(d => <div key={d} style={{ width: 7, height: 7, borderRadius: "50%", background: "#1565a0", animation: "pulse 1.2s ease-in-out infinite", animationDelay: `${d*0.2}s` }} />)}
                    <style>{`@keyframes pulse{0%,80%,100%{transform:scale(0.6);opacity:0.4}40%{transform:scale(1);opacity:1}}`}</style>
                    <span style={{ fontSize: 11.5, color: "#777", marginLeft: 5 }}>Menghitung untuk {lokasi}...</span>
                  </div>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>
          {pendingImages.length > 0 && (
            <div style={{ display: "flex", gap: 6, padding: "6px 0", flexWrap: "wrap" }}>
              {pendingImages.map((img, i) => (
                <div key={i} style={{ position: "relative" }}>
                  <img src={`data:${img.mediaType};base64,${img.base64}`} alt="" style={{ width: 62, height: 48, objectFit: "cover", borderRadius: 5, border: "2px solid #1565a0" }} />
                  <button onClick={() => setPendingImages(p=>p.filter((_,j)=>j!==i))} style={{ position: "absolute", top: -5, right: -5, width: 15, height: 15, borderRadius: "50%", background: "#e53935", border: "none", color: "white", fontSize: 10, cursor: "pointer" }}>×</button>
                </div>
              ))}
            </div>
          )}
          <div style={{ display: "flex", gap: 5, padding: "6px 0", flexWrap: "wrap" }}>
            {["Analisis gambar ini", `Estimasi biaya di ${lokasi}`, "Cek standar Permenkes OK", "Review zonasi poli"].map(q => (
              <button key={q} onClick={() => setInput(q)} style={{ background: "white", border: "1px solid #c5d5e8", color: "#1a3a5c", fontSize: 11, padding: "4px 9px", borderRadius: 20, cursor: "pointer", fontFamily: "inherit" }}>{q}</button>
            ))}
          </div>
          <div style={{ background: "white", borderRadius: 10, boxShadow: "0 2px 10px rgba(0,0,0,0.09)", border: "1px solid #c5d5e8", marginBottom: 12, overflow: "hidden" }}>
            <textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKeyDown} placeholder={`Ketik pertanyaan untuk proyek di ${lokasi}... (Enter kirim)`} style={{ width: "100%", padding: "10px 12px", border: "none", outline: "none", resize: "none", fontSize: 13, fontFamily: "inherit", minHeight: 50, maxHeight: 110, lineHeight: 1.5, boxSizing: "border-box" }} rows={2} />
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "5px 9px", borderTop: "1px solid #eef2f7", background: "#fafbfc" }}>
              <button onClick={() => fileInputRef.current?.click()} style={{ background: "#e8f0fe", border: "none", color: "#1565a0", fontSize: 11.5, padding: "5px 10px", borderRadius: 6, cursor: "pointer", fontFamily: "inherit" }}>📎 Upload Gambar</button>
              <input ref={fileInputRef} type="file" accept="image/*" multiple onChange={handleImageUpload} style={{ display: "none" }} />
              <button onClick={sendMessage} disabled={isLoading||(!input.trim()&&!pendingImages.length)} style={{ background: isLoading?"#9ab":"linear-gradient(135deg,#1565a0,#0d2b4e)", color: "white", border: "none", padding: "6px 15px", borderRadius: 7, fontSize: 12.5, fontFamily: "inherit", fontWeight: 700, cursor: isLoading?"not-allowed":"pointer" }}>
                {isLoading?"Memproses...":"Kirim →"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* AHSP */}
      {activeTab === "ahsp" && (
        <div style={{ flex: 1, maxWidth: 920, width: "100%", margin: "0 auto", padding: 12 }}>
          <div style={{ background: "white", borderRadius: 10, boxShadow: "0 2px 10px rgba(0,0,0,0.07)", overflow: "hidden" }}>
            <div style={{ padding: "11px 15px", borderBottom: "1px solid #eef2f7", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 7, background: "#f8fafc" }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: 13.5, color: "#1a3a5c" }}>📊 AHSP {lokasi} — Tahun {tahun}</div>
                <div style={{ fontSize: 11.5, color: "#666", marginTop: 1 }}>Koefisien x{koef} | {ahspData.length} item</div>
              </div>
              <input value={ahspSearch} onChange={e => setAhspSearch(e.target.value)} placeholder="Cari pekerjaan..." style={{ padding: "5px 10px", border: "1px solid #c5d5e8", borderRadius: 7, fontSize: 12, outline: "none", width: 175 }} />
            </div>
            <div style={{ padding: "9px 15px", background: "#f0f7ff", borderBottom: "1px solid #c5d5e8", display: "flex", gap: 7, flexWrap: "wrap", alignItems: "flex-end" }}>
              {[["Kode","kode","55px"],["Uraian","uraian","auto"],["Satuan","satuan","68px"],["Harga Base Jakarta","harga","130px"]].map(([lbl,field,w]) => (
                <div key={field} style={{ flex: field==="uraian"?1:"none", minWidth: field==="uraian"?150:w }}>
                  <div style={{ fontSize: 10.5, color: "#555", marginBottom: 2 }}>{lbl}</div>
                  <input value={newAhsp[field]} onChange={e => setNewAhsp({...newAhsp,[field]:e.target.value})} placeholder={lbl} type={field==="harga"?"number":"text"} style={{ padding: "5px 7px", border: "1px solid #c5d5e8", borderRadius: 5, fontSize: 12, width: "100%", boxSizing: "border-box" }} />
                </div>
              ))}
              <button onClick={() => { if (!newAhsp.kode||!newAhsp.uraian) return; setAhspData([...ahspData,{...newAhsp,harga:parseInt(newAhsp.harga)||0}]); setNewAhsp({kode:"",uraian:"",satuan:"",harga:""}); }} style={{ background: "#1565a0", color: "white", border: "none", padding: "6px 12px", borderRadius: 6, fontSize: 12, cursor: "pointer", fontFamily: "inherit", fontWeight: 600 }}>+ Tambah</button>
            </div>
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
                <thead>
                  <tr style={{ background: "#1a3a5c", color: "white" }}>
                    <th style={{ padding: "7px 11px", textAlign: "left" }}>Kode</th>
                    <th style={{ padding: "7px 11px", textAlign: "left" }}>Uraian Pekerjaan</th>
                    <th style={{ padding: "7px 8px", textAlign: "center" }}>Sat.</th>
                    <th style={{ padding: "7px 11px", textAlign: "right" }}>Base Jakarta</th>
                    <th style={{ padding: "7px 11px", textAlign: "right", background: "#1565a0" }}>📍 {lokasi} x{koef}</th>
                    <th style={{ padding: "7px 7px" }}></th>
                  </tr>
                </thead>
                <tbody>
                  {filteredAhsp.map((item, i) => (
                    <tr key={i} style={{ background: i%2===0?"white":"#f8fafc", borderBottom: "1px solid #eef2f7" }}>
                      <td style={{ padding: "6px 11px", color: "#1565a0", fontWeight: 600, fontFamily: "monospace" }}>{item.kode}</td>
                      <td style={{ padding: "6px 11px" }}>{item.uraian}</td>
                      <td style={{ padding: "6px 8px", textAlign: "center", color: "#666" }}>{item.satuan}</td>
                      <td style={{ padding: "6px 11px", textAlign: "right", fontFamily: "monospace", color: "#999", fontSize: 11 }}>{fmt(item.harga)}</td>
                      <td style={{ padding: "6px 11px", textAlign: "right", fontFamily: "monospace", fontWeight: 700, color: koef>1?"#c62828":koef<0.9?"#2e7d32":"#1565a0", background: i%2===0?"#f0f7ff":"#e8f2fc" }}>{fmt(hargaLokasi(item.harga))}</td>
                      <td style={{ padding: "6px 7px", textAlign: "center" }}><button onClick={() => setAhspData(ahspData.filter((_,j)=>j!==i))} style={{ background: "none", border: "none", color: "#e53935", cursor: "pointer", fontSize: 13 }}>×</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* KOEFISIEN */}
      {activeTab === "koefisien" && (
        <div style={{ flex: 1, maxWidth: 920, width: "100%", margin: "0 auto", padding: 12 }}>
          <div style={{ background: "white", borderRadius: 10, boxShadow: "0 2px 10px rgba(0,0,0,0.07)", overflow: "hidden" }}>
            <div style={{ padding: "11px 15px", background: "#f8fafc", borderBottom: "1px solid #eef2f7" }}>
              <div style={{ fontWeight: 700, fontSize: 13.5, color: "#1a3a5c" }}>🗺️ Tabel Koefisien Lokasi Konstruksi Nasional</div>
              <div style={{ fontSize: 11.5, color: "#666", marginTop: 2 }}>Klik baris untuk set lokasi aktif. Berbasis IKK BPS + data lapangan.</div>
            </div>
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
                <thead>
                  <tr style={{ background: "#1a3a5c", color: "white" }}>
                    <th style={{ padding: "7px 11px", textAlign: "left" }}>Kota</th>
                    <th style={{ padding: "7px 11px", textAlign: "left" }}>Provinsi</th>
                    <th style={{ padding: "7px 11px", textAlign: "center" }}>Koefisien</th>
                    <th style={{ padding: "7px 11px", textAlign: "right" }}>Rp 1.000.000 jadi</th>
                    <th style={{ padding: "7px 11px", textAlign: "left" }}>Catatan</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(LOKASI_DATA).map(([kota, info], i) => (
                    <tr key={kota} onClick={() => { setLokasi(kota); setActiveTab("chat"); }} style={{ background: kota===lokasi?"#dbeafe":i%2===0?"white":"#f8fafc", borderBottom: "1px solid #eef2f7", cursor: "pointer" }}>
                      <td style={{ padding: "6px 11px", fontWeight: kota===lokasi?700:400, color: "#1a3a5c" }}>{kota}{kota===lokasi?" ✓":""}</td>
                      <td style={{ padding: "6px 11px", color: "#555" }}>{info.provinsi}</td>
                      <td style={{ padding: "6px 11px", textAlign: "center" }}><span style={koefBadge(info.koef)}>x{info.koef}</span></td>
                      <td style={{ padding: "6px 11px", textAlign: "right", fontFamily: "monospace" }}>{fmt(Math.round(1000000*info.koef/1000)*1000)}</td>
                      <td style={{ padding: "6px 11px", color: "#888", fontSize: 11 }}>{info.catatan || "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
